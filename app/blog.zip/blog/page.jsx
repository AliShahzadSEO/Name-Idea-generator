import React from "react";
import BlogMain from "../../components/Blog/BlogMain";

const page = () => {
  return <BlogMain />;
};

export default page;
